package test;

public class Datos {

    public boolean validarUsuario(String usuario, String clave){




        //aqui necesario acceder a la base de datos, al registry

        //if(usuario.equalsIgnoreCase(""));

        return true;
    }
}
