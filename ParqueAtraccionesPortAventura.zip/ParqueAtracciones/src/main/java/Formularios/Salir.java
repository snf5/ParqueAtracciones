package Formularios;

public class Salir {
}
