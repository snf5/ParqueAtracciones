public class sensor {

    public String datos;




}
